const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const path = require('path');

const app = express();

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'THEODORE',
  password: 'Theodore@1',
  port: 5432,
});


app.use(bodyParser.json());
app.use(express.static('public')); 




app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
